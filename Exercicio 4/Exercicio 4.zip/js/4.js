// 4. Usando comandos de repetição, imprima o padrão conforme Figura 1.
let i = 1;
let linha = "";
const tam = 9;

while (i != tam){
    linha += i;
    console.log(linha);
    i++;
}