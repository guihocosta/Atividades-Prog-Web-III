// 3. Crie um tradutor da frase Olá Mundo utilizando comando condicional.
//  Se a variável estiver setada com fr, escreva na tela “Bonjour tout le monde!”
//  Se a variável estiver setada com es, escreva na tela “Hola, Mundo!”
//  Qualquer outro argumento, escreva “Hello World!”

let idioma = "fr";
if (idioma == "fr"){
    console.log("Bonjour tout le monde!");
}
else if (idioma == "es"){
    console.log("Hola, Mundo!");
}
else {
    console.log("Hello World");
}


